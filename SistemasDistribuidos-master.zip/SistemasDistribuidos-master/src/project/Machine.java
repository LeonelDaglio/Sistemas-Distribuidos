package project;

import java.util.Date;

class Machine {
    
    private String dirIP;
    
    public void Machine(){
        
    }
    
    public void setTime(Date hora){
             
    }
    
    public Date getTime(){
        
        return new Date();
    } 
    
    
    
}