package project;
import java.util.ArrayList;

class CristianSyncAlgorithm implements SyncAlgorithm {

    public void CristianSyncAlgorithm(){
        
    } 
    
    public void Syncronized(ArrayList<Machine> listamaquinas){
        
    }
}