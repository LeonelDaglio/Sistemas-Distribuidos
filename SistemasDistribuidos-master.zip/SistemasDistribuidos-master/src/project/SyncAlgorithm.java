package project;
import java.util.ArrayList;

interface SyncAlgorithm {
    
   public void Syncronized(ArrayList<Machine> listamaquinas);
    
}